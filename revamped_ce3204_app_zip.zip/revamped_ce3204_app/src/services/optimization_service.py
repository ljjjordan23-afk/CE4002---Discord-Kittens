from src.optimization.optimizer import individual_storey_groups, run_fast_grouped_optimization


def run_optimization_service(building, design_standard, input_data):
    constraints = input_data["constraints"]
    min_grade_val = int(str(constraints["min_grade"]).replace("S", ""))
    max_grade_val = int(str(constraints["max_grade"]).replace("S", ""))
    mode = input_data["run_mode"]
    search_mode = input_data.get("search_mode", "Fast")

    beam_groups = constraints["beam_groups"]
    column_groups = constraints["column_groups"]
    if mode == "Individual-Storey Optimization":
        beam_groups = individual_storey_groups(len(building.storeys))
        column_groups = individual_storey_groups(len(building.storeys))

    max_beam_candidates = None if search_mode == "Full" else int(input_data["candidate_pool"])
    max_column_candidates = None if search_mode == "Full" else int(input_data["candidate_pool"])

    return run_fast_grouped_optimization(
        base_building=building,
        design_standard=design_standard,
        beam_groups=beam_groups,
        column_groups=column_groups,
        beam_shapes=constraints["allowed_beam_shapes"],
        column_shapes=constraints["allowed_column_shapes"],
        beam_min_grade=min_grade_val,
        beam_max_grade=max_grade_val,
        column_min_grade=min_grade_val,
        column_max_grade=max_grade_val,
        u_min=constraints["u_min"],
        u_max=constraints["u_max"],
        max_beam_candidates_per_shape=max_beam_candidates,
        max_column_candidates_per_shape=max_column_candidates,
        column_class_rules=constraints["column_class_rules"],
    )
