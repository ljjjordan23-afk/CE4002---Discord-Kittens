from pathlib import Path
import sqlite3
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "sections.db"


def _normalize_header_text(value):
    if value is None:
        return ""
    text = str(value).strip().lower()
    text = text.replace("\n", " ")
    text = text.replace("_", " ")
    text = text.replace("-", " ")
    text = " ".join(text.split())
    return text


def _first_existing_column(df, candidates):
    lowered = {_normalize_header_text(col): col for col in df.columns}
    for cand in candidates:
        key = _normalize_header_text(cand)
        if key in lowered:
            return lowered[key]
    return None


def _fallback_first_column(df):
    if len(df.columns) == 0:
        return None
    return df.columns[0]


def _find_section_class_column(df):
    # First try normal header matching
    class_col = _first_existing_column(df, ["section class", "class"])
    if class_col is not None:
        return class_col

    # Fallback for your workbook:
    # after header=1, class column becomes Unnamed:* and sits at the last column
    unnamed_cols = [col for col in df.columns if str(col).startswith("Unnamed:")]
    if unnamed_cols:
        return unnamed_cols[-1]

    # final fallback: use last column if nothing else works
    if len(df.columns) > 0:
        return df.columns[-1]

    return None


def _normalize_section_sheet(df, shape_name):
    df = df.copy()

    name_col = _first_existing_column(
        df,
        ["section name", "profile", "section", "name", "designation"]
    )

    if name_col is None:
        name_col = _fallback_first_column(df)

    area_col = _first_existing_column(
        df,
        ["area", "a"]
    )
    weight_col = _first_existing_column(
        df,
        ["weight", "mass", "kg/m", "mass (kg/m)"]
    )
    i_col = _first_existing_column(
        df,
        ["second moment of area", "iy", "i", "i_y", "i y"]
    )
    w_col = _first_existing_column(
        df,
        ["elastic section modulus", "wel,y", "wel", "wely", "section modulus"]
    )

    class_col = _find_section_class_column(df)

    required = [name_col, area_col, weight_col, i_col, w_col]
    if any(col is None for col in required):
        raise ValueError(
            f"Could not map the required columns in sheet for shape {shape_name}. "
            f"Please check the section Excel column headers."
        )

    out = pd.DataFrame({
        "name": df[name_col],
        "shape": shape_name,
        "area": pd.to_numeric(df[area_col], errors="coerce"),
        "weight": pd.to_numeric(df[weight_col], errors="coerce"),
        "I": pd.to_numeric(df[i_col], errors="coerce"),
        "W": pd.to_numeric(df[w_col], errors="coerce"),
        "section_class": pd.to_numeric(df[class_col], errors="coerce") if class_col is not None else pd.NA,
    })

    # remove symbol row / unit row / blank rows
    out = out.dropna(subset=["name", "area", "weight", "I", "W"])
    out["name"] = out["name"].astype(str).str.replace("\xa0", " ", regex=False).str.strip()

    out = out[out["name"] != ""]
    out = out[~out["name"].str.lower().isin(["section name", "profile"])]

    return out


def build_database_from_excels():
    member_path = DATA_DIR / "member_section.xlsx"
    material_path = DATA_DIR / "material_cost.xlsx"
    standard_path = DATA_DIR / "design_standard.xlsx"

    missing = [p.name for p in [member_path, material_path, standard_path] if not p.exists()]
    if missing:
        raise FileNotFoundError(f"Missing required Excel files in data/: {missing}")

    xls = pd.ExcelFile(member_path)
    all_sections = []

    for sheet in xls.sheet_names:
        sheet_lower = sheet.strip().lower()

        if "chs" in sheet_lower or "circular" in sheet_lower:
            shape = "CHS"
        elif "shs" in sheet_lower or "square" in sheet_lower:
            shape = "SHS"
        elif "i section" in sheet_lower or sheet_lower == "i sections":
            shape = "I"
        else:
            continue

        # keep header=1 for main labels
        df_sheet = pd.read_excel(member_path, sheet_name=sheet, header=1)
        all_sections.append(_normalize_section_sheet(df_sheet, shape))

    if not all_sections:
        raise ValueError("No recognizable section sheets found in member_section.xlsx")

    sections_df = pd.concat(all_sections, ignore_index=True)

    mat_df = pd.read_excel(material_path)
    mat_grade = _first_existing_column(mat_df, ["steel grade", "grade"])
    mat_fy = _first_existing_column(mat_df, ["yield strength (mpa)", "yield strength", "fy"])
    mat_cost = _first_existing_column(mat_df, ["cost (sgd per kg)", "cost", "price"])

    if any(col is None for col in [mat_grade, mat_fy, mat_cost]):
        raise ValueError("Could not map material_cost.xlsx columns to grade, fy, cost")

    materials_df = pd.DataFrame({
        "grade": mat_df[mat_grade].astype(str).str.strip(),
        "fy": pd.to_numeric(mat_df[mat_fy], errors="coerce"),
        "cost": pd.to_numeric(mat_df[mat_cost], errors="coerce"),
    }).dropna()

    std_df = pd.read_excel(standard_path)
    std_code = _first_existing_column(std_df, ["design code", "code", "standard", "design standard"])
    std_alpha = _first_existing_column(std_df, ["alpha", "α"])
    std_beta = _first_existing_column(std_df, ["beta", "β"])

    if any(col is None for col in [std_code, std_alpha, std_beta]):
        raise ValueError("Could not map design_standard.xlsx columns to code, alpha, beta")

    standards_df = pd.DataFrame({
        "code": std_df[std_code].astype(str).str.strip(),
        "alpha": pd.to_numeric(std_df[std_alpha], errors="coerce"),
        "beta": pd.to_numeric(std_df[std_beta], errors="coerce"),
    }).dropna()

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)

    sections_df.to_sql("sections", conn, if_exists="replace", index=False)
    materials_df.to_sql("materials", conn, if_exists="replace", index=False)
    standards_df.to_sql("design_standards", conn, if_exists="replace", index=False)

    conn.close()
    return DB_PATH


if __name__ == "__main__":
    db_path = build_database_from_excels()
    print(f"Database built successfully at: {db_path}")