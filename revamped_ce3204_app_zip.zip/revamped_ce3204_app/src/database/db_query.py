import sqlite3
from pathlib import Path
from typing import Iterable, Optional

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "sections.db"


def get_connection():
    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"Database not found at {DB_PATH}. Add your Excel files into data/ and run: python -m src.database.import_from_excel"
        )
    return sqlite3.connect(DB_PATH)


def get_all_sections(shape: Optional[str] = None):
    conn = get_connection()
    cur = conn.cursor()
    if shape is None:
        cur.execute("SELECT name, shape, area, weight, I, W, section_class FROM sections")
    else:
        cur.execute(
            "SELECT name, shape, area, weight, I, W, section_class FROM sections WHERE shape = ?",
            (shape,),
        )
    rows = cur.fetchall()
    conn.close()
    return rows


def get_section(name: str):
    normalized = str(name).replace("\xa0", " ").strip()
    rows = get_all_sections()
    for row in rows:
        row_name = str(row[0]).replace("\xa0", " ").strip()
        if row_name == normalized:
            return row
    return None


def get_all_materials():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT grade, fy, cost FROM materials")
    rows = cur.fetchall()
    conn.close()
    return rows


def get_material(grade: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT grade, fy, cost FROM materials WHERE grade = ?", (grade,))
    row = cur.fetchone()
    conn.close()
    return row


def get_all_design_standards():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT code, alpha, beta FROM design_standards")
    rows = cur.fetchall()
    conn.close()
    return rows


def get_design_standard(code: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT code, alpha, beta FROM design_standards WHERE code = ?", (code,))
    row = cur.fetchone()
    conn.close()
    return row


def get_all_section_names():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT name FROM sections ORDER BY name")
    rows = cur.fetchall()
    conn.close()
    return [r[0] for r in rows]


def get_all_material_grades():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT grade FROM materials ORDER BY fy")
    rows = cur.fetchall()
    conn.close()
    return [r[0] for r in rows]


def get_all_design_standard_codes():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT code FROM design_standards ORDER BY code")
    rows = cur.fetchall()
    conn.close()
    return [r[0] for r in rows]


def get_unique_sections_by_shape_sorted(shape: str, sort_by: str = "weight"):
    rows = get_all_sections(shape=shape)
    seen = set()
    unique_rows = []
    for row in rows:
        if row[0] not in seen:
            seen.add(row[0])
            unique_rows.append(row)

    field_index = {
        "name": 0,
        "area": 2,
        "weight": 3,
        "I": 4,
        "W": 5,
        "section_class": 6,
    }
    idx = field_index.get(sort_by, 3)
    unique_rows.sort(key=lambda r: (r[idx] is None, r[idx]))
    return unique_rows


def grade_to_value(grade) -> int:
    if isinstance(grade, (int, float)):
        return int(grade)
    return int(str(grade).replace("S", "").strip())


def get_materials_in_grade_range(min_grade, max_grade):
    rows = get_all_materials()
    min_val = grade_to_value(min_grade)
    max_val = grade_to_value(max_grade)
    filtered = [row for row in rows if min_val <= grade_to_value(row[0]) <= max_val]
    filtered.sort(key=lambda r: grade_to_value(r[0]))
    return filtered


def database_ready() -> bool:
    return DB_PATH.exists()
