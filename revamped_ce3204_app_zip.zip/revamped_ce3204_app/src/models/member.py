class Member:
    def __init__(self, section, material, length, storey):
        self.section = section
        self.material = material
        self.length = float(length)
        self.storey = int(storey)

    def weight(self):
        return self.section.weight * self.length

    def cost(self):
        return self.weight() * self.material.cost
