class Section:
    def __init__(self, name, shape, area, weight, I, W, section_class):
        self.name = name
        self.shape = shape
        self.area = float(area)
        self.weight = float(weight)
        self.I = float(I)
        self.W = float(W)
        self.section_class = int(section_class) if section_class is not None and str(section_class).strip() != "" else None

    def __repr__(self):
        return (
            f"Section(name={self.name}, shape={self.shape}, area={self.area}, "
            f"weight={self.weight}, I={self.I}, W={self.W}, class={self.section_class})"
        )
