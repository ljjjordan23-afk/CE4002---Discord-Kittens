import numpy as np
from src.models.member import Member


class Beam(Member):
    def max_moment(self, w_kN_per_m, span_m):
        return float(w_kN_per_m) * (float(span_m) ** 2) / 12.0

    def max_stress(self, w_kN_per_m, span_m):
        moment_n_mm = self.max_moment(w_kN_per_m, span_m) * 1e6
        section_modulus_mm3 = self.section.W * 1e3
        return moment_n_mm / section_modulus_mm3

    def utilization(self, w_kN_per_m, span_m):
        return self.max_stress(w_kN_per_m, span_m) / self.material.fy

    def max_deflection(self, w_kN_per_m, span_m):
        e_mpa = 210000.0
        w_n_per_mm = float(w_kN_per_m)
        l_mm = float(span_m) * 1000.0
        i_mm4 = self.section.I * 1e6
        return (w_n_per_mm * (l_mm ** 4)) / (384.0 * e_mpa * i_mm4)

    def beam_diagram_data(self, w_kN_per_m, span_m, n_points=200):
        e_mpa = 210000.0
        i_mm4 = self.section.I * 1e6
        x_m = np.linspace(0.0, float(span_m), int(n_points))
        l_m = float(span_m)
        w = float(w_kN_per_m)

        v_kN = w * (l_m / 2.0 - x_m)
        m_kNm = -(w * l_m**2) / 12.0 + (w * l_m * x_m) / 2.0 - (w * x_m**2) / 2.0

        x_mm = x_m * 1000.0
        l_mm = l_m * 1000.0
        y_mm = w * (x_mm**2) * ((l_mm - x_mm) ** 2) / (24.0 * e_mpa * i_mm4)

        return {"x_m": x_m, "V_kN": v_kN, "M_kNm": m_kNm, "y_mm": y_mm}
