import math
from src.models.member import Member


class Column(Member):
    def max_stress(self, p_kN):
        p_n = float(p_kN) * 1000.0
        area_mm2 = self.section.area
        return p_n / area_mm2

    def axial_utilization(self, p_kN):
        return self.max_stress(p_kN) / self.material.fy

    def buckling_capacity(self, length_m, K=1.0):
        e_mpa = 210000.0
        i_mm4 = self.section.I * 1e6
        kl_mm = float(K) * float(length_m) * 1000.0
        pcr_n = (math.pi ** 2) * e_mpa * i_mm4 / (kl_mm ** 2)
        return pcr_n / 1000.0

    def buckling_utilization(self, p_kN, length_m, K=1.0):
        cap = self.buckling_capacity(length_m, K=K)
        return float("inf") if cap <= 0 else float(p_kN) / cap

    def governing_utilization(self, p_kN, length_m, K=1.0):
        return max(self.axial_utilization(p_kN), self.buckling_utilization(p_kN, length_m, K=K))
