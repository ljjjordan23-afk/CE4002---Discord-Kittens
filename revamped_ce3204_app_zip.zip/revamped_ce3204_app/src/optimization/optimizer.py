from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from time import perf_counter
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from src.analysis.analysis_engine import compute_storey_design_actions, run_analysis
from src.database.db_query import get_materials_in_grade_range, get_unique_sections_by_shape_sorted
from src.models.material import Material
from src.models.section import Section

VALID_SHAPES = {"I", "SHS", "CHS"}


@dataclass
class CandidateChoice:
    section: Section
    material: Material


@dataclass
class GroupEvaluation:
    group: List[int]
    section: str
    grade: str
    max_utilization: float
    total_cost: float



def _as_shape_list(shapes) -> List[str]:
    if shapes is None:
        return []
    if isinstance(shapes, str):
        shapes = [shapes]
    out = []
    for item in shapes:
        shape = str(item).strip().upper()
        if shape not in VALID_SHAPES:
            raise ValueError(f"Invalid shape '{shape}'. Allowed shapes are {sorted(VALID_SHAPES)}")
        if shape not in out:
            out.append(shape)
    return out


def _sorted_unique_ints(values: Iterable[int]) -> List[int]:
    return sorted({int(v) for v in values})


def normalize_groups(groups: Optional[Sequence[Sequence[int]]], n_storeys: int) -> List[List[int]]:
    if not groups:
        return [[i] for i in range(1, n_storeys + 1)]
    normalized = []
    seen = []
    for group in groups:
        if not group:
            raise ValueError("A group cannot be empty.")
        vals = _sorted_unique_ints(group)
        for storey in vals:
            if storey < 1 or storey > n_storeys:
                raise ValueError(f"Storey {storey} is out of range 1..{n_storeys}")
        normalized.append(vals)
        seen.extend(vals)
    if sorted(seen) != list(range(1, n_storeys + 1)):
        raise ValueError("Groups must cover every storey exactly once.")
    return normalized


def normalize_column_class_rules(column_class_rules: Optional[List[Dict]], n_storeys: int) -> List[Dict]:
    if not column_class_rules:
        return []
    out = []
    for idx, rule in enumerate(column_class_rules, start=1):
        if "storeys" not in rule or "allowed_classes" not in rule:
            raise ValueError(f"Column class rule #{idx} must contain 'storeys' and 'allowed_classes'.")
        storeys = _sorted_unique_ints(rule["storeys"])
        allowed_classes = _sorted_unique_ints(rule["allowed_classes"])
        for storey in storeys:
            if storey < 1 or storey > n_storeys:
                raise ValueError(f"Column class rule #{idx} has invalid storey {storey}")
        for section_class in allowed_classes:
            if section_class not in {1, 2, 3, 4}:
                raise ValueError(f"Column class rule #{idx} has invalid class {section_class}")
        out.append({"storeys": storeys, "allowed_classes": allowed_classes})
    return out


def individual_storey_groups(n_storeys: int) -> List[List[int]]:
    return [[i] for i in range(1, n_storeys + 1)]


def build_design_candidates(
    shapes,
    min_grade,
    max_grade,
    sort_by="weight",
    max_candidates_per_shape: Optional[int] = None,
):
    shape_list = _as_shape_list(shapes)
    all_section_rows = []
    seen = set()
    for shape in shape_list:
        rows = get_unique_sections_by_shape_sorted(shape, sort_by=sort_by)
        if max_candidates_per_shape is not None:
            rows = rows[: int(max_candidates_per_shape)]
        for row in rows:
            if row[0] not in seen:
                all_section_rows.append(row)
                seen.add(row[0])

    material_rows = get_materials_in_grade_range(min_grade, max_grade)
    sections = [Section(*row) for row in all_section_rows]
    materials = [Material(*row) for row in material_rows]
    return [CandidateChoice(section=s, material=m) for s in sections for m in materials]


def get_column_force_map(building, design_standard):
    return {item["storey"].level: item["column_force"] for item in compute_storey_design_actions(building, design_standard)}


def get_design_load_map(building, design_standard):
    return {item["storey"].level: item["w"] for item in compute_storey_design_actions(building, design_standard)}


def _passes_column_class_rules(section: Section, group: List[int], column_class_rules: List[Dict]) -> bool:
    if not column_class_rules:
        return True
    for rule in column_class_rules:
        if any(storey in rule["storeys"] for storey in group):
            if section.section_class not in set(rule["allowed_classes"]):
                return False
    return True


def _evaluate_beam_group(base_building, design_load_map, group, choice, u_min, u_max):
    max_util = -1.0
    total_cost = 0.0
    for storey in base_building.storeys:
        if storey.level not in group:
            continue
        beam = deepcopy(storey.beam)
        beam.section = choice.section
        beam.material = choice.material
        w = design_load_map[storey.level]
        util = beam.utilization(w, base_building.span)
        if u_min is not None and util < u_min:
            return None
        if u_max is not None and util > u_max:
            return None
        max_util = max(max_util, util)
        total_cost += beam.cost()
    return GroupEvaluation(group=list(group), section=choice.section.name, grade=choice.material.grade, max_utilization=max_util, total_cost=total_cost)


def _evaluate_column_group(base_building, column_force_map, group, choice, u_min, u_max, column_class_rules):
    if not _passes_column_class_rules(choice.section, group, column_class_rules):
        return None
    max_util = -1.0
    total_cost = 0.0
    for storey in base_building.storeys:
        if storey.level not in group:
            continue
        column = deepcopy(storey.column_left)
        column.section = choice.section
        column.material = choice.material
        p = column_force_map[storey.level]
        util = column.axial_utilization(p)
        if u_min is not None and util < u_min:
            return None
        if u_max is not None and util > u_max:
            return None
        max_util = max(max_util, util)
        total_cost += 2.0 * column.cost()
    return GroupEvaluation(group=list(group), section=choice.section.name, grade=choice.material.grade, max_utilization=max_util, total_cost=total_cost)


def _apply_group_choice_to_building(building, groups, group_evaluations, member_type):
    evaluation_map = {tuple(ev.group): ev for ev in group_evaluations}
    for group in groups:
        ev = evaluation_map[tuple(group)]
        for storey in building.storeys:
            if storey.level not in group:
                continue
            if member_type == "beam":
                storey.beam.section = Section(*get_unique_sections_by_shape_sorted(storey.beam.section.shape)[0])  # placeholder overwritten below
            # values are set later in service with original object lookup disabled here
    return building


def _assign_choices(building, beam_groups, beam_choices, column_groups, column_choices):
    beam_choice_by_storey = {}
    for group, choice in zip(beam_groups, beam_choices):
        for storey in group:
            beam_choice_by_storey[storey] = choice
    column_choice_by_storey = {}
    for group, choice in zip(column_groups, column_choices):
        for storey in group:
            column_choice_by_storey[storey] = choice

    candidate = deepcopy(building)
    for storey in candidate.storeys:
        beam_choice = beam_choice_by_storey[storey.level]
        column_choice = column_choice_by_storey[storey.level]
        storey.beam.section = beam_choice.section
        storey.beam.material = beam_choice.material
        storey.column_left.section = column_choice.section
        storey.column_right.section = column_choice.section
        storey.column_left.material = column_choice.material
        storey.column_right.material = column_choice.material
    return candidate


def run_fast_grouped_optimization(
    base_building,
    design_standard,
    beam_groups=None,
    column_groups=None,
    beam_shapes=("I",),
    column_shapes=("SHS", "CHS"),
    beam_min_grade=235,
    beam_max_grade=355,
    column_min_grade=235,
    column_max_grade=355,
    u_min=0.2,
    u_max=0.7,
    max_beam_candidates_per_shape=None,
    max_column_candidates_per_shape=None,
    column_class_rules=None,
):
    start = perf_counter()
    n_storeys = len(base_building.storeys)
    beam_groups = normalize_groups(beam_groups, n_storeys)
    column_groups = normalize_groups(column_groups, n_storeys)
    column_class_rules = normalize_column_class_rules(column_class_rules, n_storeys)

    design_load_map = get_design_load_map(base_building, design_standard)
    column_force_map = get_column_force_map(base_building, design_standard)

    beam_candidates = build_design_candidates(
        shapes=beam_shapes,
        min_grade=beam_min_grade,
        max_grade=beam_max_grade,
        sort_by="weight",
        max_candidates_per_shape=max_beam_candidates_per_shape,
    )
    column_candidates = build_design_candidates(
        shapes=column_shapes,
        min_grade=column_min_grade,
        max_grade=column_max_grade,
        sort_by="weight",
        max_candidates_per_shape=max_column_candidates_per_shape,
    )

    if not beam_candidates:
        raise ValueError("No beam candidates available after filters.")
    if not column_candidates:
        raise ValueError("No column candidates available after filters.")

    chosen_beam_choices = []
    beam_group_summaries = []
    beam_evals = 0
    for group in beam_groups:
        best = None
        best_choice = None
        for choice in beam_candidates:
            beam_evals += 1
            evaluation = _evaluate_beam_group(base_building, design_load_map, group, choice, u_min, u_max)
            if evaluation is None:
                continue
            if best is None or evaluation.total_cost < best.total_cost:
                best = evaluation
                best_choice = choice
        if best is None:
            return {
                "building": None,
                "results": None,
                "summary": None,
                "best_beam_designs": None,
                "best_column_designs": None,
                "group_summaries": None,
                "meta": {
                    "success": False,
                    "failure_reason": f"No feasible beam design found for group {group}",
                    "beam_candidates_tested": beam_evals,
                    "column_candidates_tested": 0,
                    "runtime_sec": perf_counter() - start,
                },
            }
        chosen_beam_choices.append(best_choice)
        beam_group_summaries.append(best)

    chosen_column_choices = []
    column_group_summaries = []
    column_evals = 0
    for group in column_groups:
        best = None
        best_choice = None
        for choice in column_candidates:
            column_evals += 1
            evaluation = _evaluate_column_group(base_building, column_force_map, group, choice, u_min, u_max, column_class_rules)
            if evaluation is None:
                continue
            if best is None or evaluation.total_cost < best.total_cost:
                best = evaluation
                best_choice = choice
        if best is None:
            return {
                "building": None,
                "results": None,
                "summary": None,
                "best_beam_designs": None,
                "best_column_designs": None,
                "group_summaries": None,
                "meta": {
                    "success": False,
                    "failure_reason": f"No feasible column design found for group {group}",
                    "beam_candidates_tested": beam_evals,
                    "column_candidates_tested": column_evals,
                    "runtime_sec": perf_counter() - start,
                },
            }
        chosen_column_choices.append(best_choice)
        column_group_summaries.append(best)

    candidate = _assign_choices(base_building, beam_groups, chosen_beam_choices, column_groups, chosen_column_choices)
    results, summary = run_analysis(candidate, design_standard)

    return {
        "building": candidate,
        "results": results,
        "summary": summary,
        "best_beam_designs": [{"section": c.section.name, "grade": c.material.grade} for c in chosen_beam_choices],
        "best_column_designs": [{"section": c.section.name, "grade": c.material.grade} for c in chosen_column_choices],
        "group_summaries": {
            "beam": [ev.__dict__ for ev in beam_group_summaries],
            "column": [ev.__dict__ for ev in column_group_summaries],
        },
        "meta": {
            "success": True,
            "search_mode": "Full" if max_beam_candidates_per_shape is None and max_column_candidates_per_shape is None else "Fast",
            "beam_groups": beam_groups,
            "column_groups": column_groups,
            "beam_candidates_available": len(beam_candidates),
            "column_candidates_available": len(column_candidates),
            "beam_candidates_tested": beam_evals,
            "column_candidates_tested": column_evals,
            "runtime_sec": perf_counter() - start,
        },
    }
