from src.database.db_query import get_design_standard, get_material, get_section
from src.models.beam import Beam
from src.models.building import Building
from src.models.column import Column
from src.models.design_standard import DesignStandard
from src.models.material import Material
from src.models.section import Section
from src.models.storey import Storey


def default_storey_rows(num_storeys: int):
    rows = []
    for level in range(1, num_storeys + 1):
        rows.append(
            {
                "level": level,
                "height": 3.0,
                "dead_load": 5.0,
                "live_load": 3.0,
                "beam_section": "",
                "beam_grade": "",
                "column_section": "",
                "column_grade": "",
            }
        )
    return rows


def build_building_from_rows(num_storeys, span, design_standard_code, storey_rows):
    design_row = get_design_standard(design_standard_code)
    if design_row is None:
        raise ValueError(f"Design standard not found: {design_standard_code}")
    design_standard = DesignStandard(*design_row)

    storeys = []
    for row in storey_rows:
        beam_section_row = get_section(row["beam_section"])
        column_section_row = get_section(row["column_section"])
        beam_material_row = get_material(row["beam_grade"])
        column_material_row = get_material(row["column_grade"])

        if beam_section_row is None:
            raise ValueError(f"Beam section not found: {row['beam_section']}")
        if column_section_row is None:
            raise ValueError(f"Column section not found: {row['column_section']}")
        if beam_material_row is None:
            raise ValueError(f"Beam grade not found: {row['beam_grade']}")
        if column_material_row is None:
            raise ValueError(f"Column grade not found: {row['column_grade']}")

        beam_section = Section(*beam_section_row)
        beam_material = Material(*beam_material_row)
        column_section = Section(*column_section_row)
        column_material = Material(*column_material_row)

        beam = Beam(beam_section, beam_material, span, row["level"])
        column_left = Column(column_section, column_material, row["height"], row["level"])
        column_right = Column(column_section, column_material, row["height"], row["level"])

        storeys.append(
            Storey(
                level=row["level"],
                height=row["height"],
                dead_load=row["dead_load"],
                live_load=row["live_load"],
                beam=beam,
                column_left=column_left,
                column_right=column_right,
            )
        )

    building = Building(num_storeys=num_storeys, span=span, storeys=storeys)
    return building, design_standard
