from typing import List


def groups_to_text(groups):
    parts = []
    for group in groups:
        if len(group) == 1:
            parts.append(str(group[0]))
        elif group == list(range(group[0], group[-1] + 1)):
            parts.append(f"{group[0]}-{group[-1]}")
        else:
            parts.append(",".join(str(x) for x in group))
    return " | ".join(parts)


def parse_group_string(group_text: str) -> List[List[int]]:
    groups = []
    parts = [p.strip() for p in str(group_text).split("|") if p.strip()]
    for part in parts:
        values = []
        for token in [s.strip() for s in part.split(",") if s.strip()]:
            if "-" in token:
                a_text, b_text = token.split("-", 1)
                a = int(a_text.strip())
                b = int(b_text.strip())
                if a > b:
                    raise ValueError(f"Invalid range '{token}'.")
                values.extend(list(range(a, b + 1)))
            else:
                values.append(int(token))
        groups.append(sorted(set(values)))
    return groups


def parse_class_list(class_text: str):
    if str(class_text).strip() == "":
        return []
    return [int(x.strip()) for x in str(class_text).split(",") if x.strip()]


def format_storey_group(group):
    if len(group) == 1:
        return f"Storey {group[0]}"
    return "Storeys " + ", ".join(str(v) for v in group)
