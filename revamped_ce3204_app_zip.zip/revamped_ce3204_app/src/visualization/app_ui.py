from pathlib import Path
import sys
from dataclasses import dataclass
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[2]
if str(BASE_DIR) not in sys.path:
    sys.path.append(str(BASE_DIR))

import pandas as pd
import streamlit as st

from src.analysis.analysis_engine import export_results_to_excel
from src.database.db_query import (
    database_ready,
    get_all_design_standard_codes,
    get_all_material_grades,
    get_all_section_names,
)
from src.io.builders import build_building_from_rows, default_storey_rows
from src.services.analysis_service import run_analysis_service
from src.services.optimization_service import run_optimization_service
from src.utils.parsing import format_storey_group, groups_to_text, parse_class_list, parse_group_string
from src.visualization.charts import (
    create_beam_bmd_plot,
    create_beam_deflection_plot,
    create_beam_sfd_plot,
    create_frame_figure,
)


def _inject_css():
    st.markdown(
        """
        <style>
        .block-container {padding-top: 1.1rem; padding-bottom: 2rem;}
        .section-card {
            border: 1px solid #D9E2F1;
            border-radius: 14px;
            padding: 1rem 1rem 0.85rem 1rem;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FBFF 100%);
            box-shadow: 0 2px 10px rgba(15, 23, 42, 0.05);
            margin-bottom: 1rem;
        }
        .section-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #1F2937;
            margin-bottom: 0.25rem;
        }
        .section-subtitle {
            font-size: 0.92rem;
            color: #475569;
            margin-bottom: 0.7rem;
        }
        .hint-box {
            border-left: 4px solid #2563EB;
            background: #EFF6FF;
            padding: 0.75rem 0.9rem;
            border-radius: 8px;
            color: #1E3A8A;
            margin: 0.35rem 0 0.75rem 0;
        }
        .table-header {
            font-weight: 700;
            color: #1F2937;
            font-size: 0.92rem;
            padding-bottom: 0.25rem;
        }
        .row-divider {
            margin-top: 0.35rem;
            margin-bottom: 0.35rem;
            border-bottom: 1px solid #E5E7EB;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _normalize_search_text(text: str) -> str:
    text = str(text or "").lower().strip()
    for ch in ["/", "-", "_", ",", ".", "(", ")", "[", "]"]:
        text = text.replace(ch, " ")
    text = " ".join(text.split())
    return text


@dataclass(frozen=True)
class SectionChoice:
    label: str
    search_text: str

    def __str__(self) -> str:
        return self.search_text


def _make_section_choice(section_name: str) -> SectionChoice:
    raw = str(section_name).strip()
    norm = _normalize_search_text(raw)
    compact = norm.replace(" ", "")
    aliases = [raw, norm, compact]

    if raw.lower().startswith("ub"):
        digits = "".join(ch for ch in raw.lower() if ch.isdigit() or ch == "x")
        aliases.extend([raw.lower().replace(" ", ""), f"ub {digits}", f"ub{digits}"])

    if raw.lower().startswith("shs"):
        compact_num = raw.lower().replace("shs", "").replace(" ", "").replace("/", "")
        aliases.extend([f"shs{compact_num}", f"shs {compact_num}"])

    if raw.lower().startswith("chs"):
        compact_num = raw.lower().replace("chs", "").replace(" ", "")
        aliases.extend([f"chs{compact_num}", f"chs {compact_num}"])

    searchable = " | ".join(dict.fromkeys(a for a in aliases if a))
    return SectionChoice(label=raw, search_text=searchable)


def _build_section_choices(all_sections):
    return [_make_section_choice(section) for section in all_sections]


def _default_groups(num_storeys: int):
    if num_storeys == 1:
        return [[1]], [[1]]
    if num_storeys == 2:
        return [[1], [2]], [[1], [2]]
    if num_storeys >= 5:
        return [[1], list(range(2, num_storeys)), [num_storeys]], [list(range(1, num_storeys)), [num_storeys]]
    return [[i] for i in range(1, num_storeys + 1)], [[i] for i in range(1, num_storeys + 1)]


def _prepare_live_row_state(num_storeys: int, all_sections, all_grades):
    key = "live_storey_rows"

    if key not in st.session_state:
        base_rows = default_storey_rows(num_storeys)
        for row in base_rows:
            row["beam_section"] = row.get("beam_section") or all_sections[0]
            row["beam_grade"] = row.get("beam_grade") or all_grades[0]
            row["column_section"] = row.get("column_section") or all_sections[0]
            row["column_grade"] = row.get("column_grade") or all_grades[0]
        st.session_state[key] = base_rows

    rows = st.session_state[key]

    if len(rows) < num_storeys:
        for i in range(len(rows) + 1, num_storeys + 1):
            new_row = default_storey_rows(1)[0]
            new_row["level"] = i
            new_row["beam_section"] = all_sections[0]
            new_row["beam_grade"] = all_grades[0]
            new_row["column_section"] = all_sections[0]
            new_row["column_grade"] = all_grades[0]
            rows.append(new_row)
    elif len(rows) > num_storeys:
        rows = rows[:num_storeys]

    for i, row in enumerate(rows, start=1):
        row["level"] = i
        row.setdefault("beam_section", all_sections[0])
        row.setdefault("beam_grade", all_grades[0])
        row.setdefault("column_section", all_sections[0])
        row.setdefault("column_grade", all_grades[0])

    st.session_state[key] = rows
    return rows


def _render_live_storey_inputs(num_storeys: int, all_sections, all_grades):
    rows = _prepare_live_row_state(num_storeys, all_sections, all_grades)
    section_choices = _build_section_choices(all_sections)
    section_label_to_choice = {choice.label: choice for choice in section_choices}

    header = st.columns([0.55, 0.85, 0.95, 0.95, 1.55, 1.15, 1.55, 1.15])
    titles = ["Storey", "Height (m)", "Dead Load", "Live Load", "Beam Section", "Beam Grade", "Column Section", "Column Grade"]
    for col, title in zip(header, titles):
        col.markdown(f"<div class='table-header'>{title}</div>", unsafe_allow_html=True)

    for i, row in enumerate(rows):
        # initialize session_state BEFORE creating widgets
        if f"height_{i}" not in st.session_state:
            st.session_state[f"height_{i}"] = float(row.get("height", 3.0))
        if f"dead_{i}" not in st.session_state:
            st.session_state[f"dead_{i}"] = float(row.get("dead_load", 5.0))
        if f"live_{i}" not in st.session_state:
            st.session_state[f"live_{i}"] = float(row.get("live_load", 3.0))

        current_beam_label = row.get("beam_section", all_sections[0])
        current_beam_choice = section_label_to_choice.get(current_beam_label, section_choices[0])
        if f"beam_section_{i}" not in st.session_state:
            st.session_state[f"beam_section_{i}"] = current_beam_choice

        current_beam_grade = row.get("beam_grade", all_grades[0])
        if f"beam_grade_{i}" not in st.session_state:
            st.session_state[f"beam_grade_{i}"] = current_beam_grade if current_beam_grade in all_grades else all_grades[0]

        current_column_label = row.get("column_section", all_sections[0])
        current_column_choice = section_label_to_choice.get(current_column_label, section_choices[0])
        if f"column_section_{i}" not in st.session_state:
            st.session_state[f"column_section_{i}"] = current_column_choice

        current_col_grade = row.get("column_grade", all_grades[0])
        if f"column_grade_{i}" not in st.session_state:
            st.session_state[f"column_grade_{i}"] = current_col_grade if current_col_grade in all_grades else all_grades[0]

        cols = st.columns([0.55, 0.85, 0.95, 0.95, 1.55, 1.15, 1.55, 1.15])

        with cols[0]:
            st.markdown(f"**{i + 1}**")

        with cols[1]:
            st.number_input(
                f"Height S{i+1}",
                min_value=0.1,
                step=0.1,
                key=f"height_{i}",
                label_visibility="collapsed",
            )
            row["height"] = float(st.session_state[f"height_{i}"])

        with cols[2]:
            st.number_input(
                f"Dead S{i+1}",
                min_value=0.0,
                step=0.1,
                key=f"dead_{i}",
                label_visibility="collapsed",
            )
            row["dead_load"] = float(st.session_state[f"dead_{i}"])

        with cols[3]:
            st.number_input(
                f"Live S{i+1}",
                min_value=0.0,
                step=0.1,
                key=f"live_{i}",
                label_visibility="collapsed",
            )
            row["live_load"] = float(st.session_state[f"live_{i}"])

        with cols[4]:
            st.selectbox(
                f"Beam Section S{i+1}",
                options=section_choices,
                key=f"beam_section_{i}",
                label_visibility="collapsed",
                format_func=lambda x: x.label,
                help="Type inside the dropdown to search. Matching is case-insensitive and also works for compact inputs like UB254, UB 254, SHS40, CHS101.6/10.",
            )
            row["beam_section"] = st.session_state[f"beam_section_{i}"].label

        with cols[5]:
            st.selectbox(
                f"Beam Grade S{i+1}",
                options=all_grades,
                key=f"beam_grade_{i}",
                label_visibility="collapsed",
            )
            row["beam_grade"] = st.session_state[f"beam_grade_{i}"]

        with cols[6]:
            st.selectbox(
                f"Column Section S{i+1}",
                options=section_choices,
                key=f"column_section_{i}",
                label_visibility="collapsed",
                format_func=lambda x: x.label,
                help="Type inside the dropdown to search. Matching is case-insensitive and also works for compact inputs like UB254, UB 254, SHS40, CHS101.6/10.",
            )
            row["column_section"] = st.session_state[f"column_section_{i}"].label

        with cols[7]:
            st.selectbox(
                f"Column Grade S{i+1}",
                options=all_grades,
                key=f"column_grade_{i}",
                label_visibility="collapsed",
            )
            row["column_grade"] = st.session_state[f"column_grade_{i}"]

        st.markdown("<div class='row-divider'></div>", unsafe_allow_html=True)

    st.session_state["live_storey_rows"] = rows
    return rows


def _clean_storey_rows(df, default_section, default_grade):
    clean = df.copy().fillna("")
    expected_cols = ["level", "height", "dead_load", "live_load", "beam_section", "beam_grade", "column_section", "column_grade"]
    for col in expected_cols:
        if col not in clean.columns:
            clean[col] = ""

    for idx in range(len(clean)):
        clean.at[idx, "level"] = idx + 1
        clean.at[idx, "height"] = float(clean.at[idx, "height"] or 3.0)
        clean.at[idx, "dead_load"] = float(clean.at[idx, "dead_load"] or 5.0)
        clean.at[idx, "live_load"] = float(clean.at[idx, "live_load"] or 3.0)
        clean.at[idx, "beam_section"] = str(clean.at[idx, "beam_section"] or default_section).strip()
        clean.at[idx, "beam_grade"] = str(clean.at[idx, "beam_grade"] or default_grade).strip()
        clean.at[idx, "column_section"] = str(clean.at[idx, "column_section"] or default_section).strip()
        clean.at[idx, "column_grade"] = str(clean.at[idx, "column_grade"] or default_grade).strip()

    return clean[expected_cols].to_dict(orient="records")


def _validate_rows(storey_rows, valid_sections, valid_grades):
    errors = []
    valid_section_set = set(valid_sections)
    valid_grade_set = set(valid_grades)

    for row in storey_rows:
        s = row["level"]
        if row["beam_section"] not in valid_section_set:
            errors.append(f"Storey {s}: beam section '{row['beam_section']}' not found.")
        if row["column_section"] not in valid_section_set:
            errors.append(f"Storey {s}: column section '{row['column_section']}' not found.")
        if row["beam_grade"] not in valid_grade_set:
            errors.append(f"Storey {s}: beam grade '{row['beam_grade']}' not found.")
        if row["column_grade"] not in valid_grade_set:
            errors.append(f"Storey {s}: column grade '{row['column_grade']}' not found.")
        if float(row["height"]) <= 0:
            errors.append(f"Storey {s}: height must be positive.")
        if float(row["dead_load"]) < 0 or float(row["live_load"]) < 0:
            errors.append(f"Storey {s}: loads cannot be negative.")
    return errors


def _render_summary_cards(summary, meta=None):
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Cost (SGD)", f"{summary['total_cost_SGD']:.3f}")
    c2.metric(summary["governing_label"], f"{summary['governing_value']:.3f} {summary['governing_unit']}")
    c3.metric("Governing Member", f"{summary['governing_member_type']} @ Storey {summary['governing_storey']}")
    if meta and "runtime_sec" in meta:
        c4.metric("Runtime (s)", f"{meta['runtime_sec']:.3f}")
    else:
        c4.metric("Max Utilization", f"{summary['max_utilization']:.3f}")


def _render_constraints_panel(num_storeys, run_mode):
    beam_groups_default, column_groups_default = _default_groups(num_storeys)
    c1, c2 = st.columns(2)

    with c1:
        u_min = st.number_input("Utilization lower bound", min_value=0.0, max_value=1.5, value=0.2, step=0.05)
        u_max = st.number_input("Utilization upper bound", min_value=0.0, max_value=1.5, value=0.7, step=0.05)
        min_grade = st.selectbox("Minimum steel grade", ["S235", "S275", "S355", "S420", "S460"], index=0)
        max_grade = st.selectbox("Maximum steel grade", ["S235", "S275", "S355", "S420", "S460"], index=2)
        beam_shapes = st.multiselect("Allowed beam shapes", ["I"], default=["I"])
        column_shapes = st.multiselect("Allowed column shapes", ["SHS", "CHS"], default=["SHS", "CHS"])

    with c2:
        if run_mode == "Individual-Storey Optimization":
            beam_group_text = groups_to_text([[i] for i in range(1, num_storeys + 1)])
            column_group_text = beam_group_text
            st.text_input("Beam groups", value=beam_group_text, disabled=True)
            st.text_input("Column groups", value=column_group_text, disabled=True)
        else:
            beam_group_text = st.text_input("Beam groups", value=groups_to_text(beam_groups_default))
            column_group_text = st.text_input("Column groups", value=groups_to_text(column_groups_default))

        class_rule_storey_text = st.text_input("Column class rule storeys", value="1-3")
        class_rule_allowed_text = st.text_input("Allowed column classes for those storeys", value="1,2")
        search_mode = st.radio(
            "Search mode",
            ["Fast", "Full"],
            index=1,
            horizontal=True,
            help="Full is the accurate search over all filtered sections.",
        )
        candidate_pool = st.number_input("Candidate pool size per shape", min_value=2, max_value=40, value=8, step=1, disabled=(search_mode == "Full"))

    beam_groups = parse_group_string(beam_group_text)
    column_groups = parse_group_string(column_group_text)

    class_rule_storeys = []
    for token in [p.strip() for p in class_rule_storey_text.split(",") if p.strip()]:
        if "-" in token:
            a_text, b_text = token.split("-", 1)
            class_rule_storeys.extend(list(range(int(a_text), int(b_text) + 1)))
        else:
            class_rule_storeys.append(int(token))

    allowed_classes = parse_class_list(class_rule_allowed_text)
    column_class_rules = []
    if class_rule_storeys and allowed_classes:
        column_class_rules.append({"storeys": sorted(set(class_rule_storeys)), "allowed_classes": allowed_classes})

    return {
        "u_min": u_min,
        "u_max": u_max,
        "beam_groups": beam_groups,
        "column_groups": column_groups,
        "min_grade": min_grade,
        "max_grade": max_grade,
        "allowed_beam_shapes": beam_shapes,
        "allowed_column_shapes": column_shapes,
        "column_class_rules": column_class_rules,
        "search_mode": search_mode,
        "candidate_pool": int(candidate_pool),
    }


def _governing_highlight(summary, results):
    member_type = summary.get("max_utilization_member_type") or summary.get("governing_member_type") or "Beam"
    storey = summary.get("max_utilization_storey") or summary.get("governing_storey") or results[0]["storey"]
    return str(member_type), int(storey)


def _render_results(payload, component_label):
    summary = payload["summary"]
    results = payload["results"]
    building = payload["building"]
    meta = payload.get("meta")

    _render_summary_cards(summary, meta=meta)

    tab_summary, tab_table, tab_frame, tab_diagrams, tab_export = st.tabs(
        ["Summary", "Results Table", "Frame Viewer", "Beam Diagrams", "Export"]
    )

    with tab_summary:
        st.subheader(f"{component_label} Summary")
        left, right = st.columns([1.2, 1])
        with left:
            st.json(summary)
        with right:
            if meta:
                st.subheader("Search / Runtime Meta")
                st.json(meta)
            if payload.get("group_summaries"):
                st.subheader("Group Selections")
                grp = payload["group_summaries"]
                if grp.get("beam"):
                    st.markdown("**Beam Groups**")
                    for item in grp["beam"]:
                        st.write(f"{format_storey_group(item['group'])}: {item['section']} | {item['grade']} | Umax = {item['max_utilization']:.3f}")
                if grp.get("column"):
                    st.markdown("**Column Groups**")
                    for item in grp["column"]:
                        st.write(f"{format_storey_group(item['group'])}: {item['section']} | {item['grade']} | Umax = {item['max_utilization']:.3f}")

    with tab_table:
        st.dataframe(pd.DataFrame(results), use_container_width=True, hide_index=True, height=520)
    
    with tab_frame:
        selected_member_type, selected_storey = _governing_highlight(summary, results)
        st.markdown(
            f"""
            <div class="hint-box">
            <b>Governing highlighted member</b><br>
            {selected_member_type} — Storey {selected_storey}
            </div>
            """,
            unsafe_allow_html=True,
        )

        fig = create_frame_figure(
            building,
            results,
            selected_storey=selected_storey,
            selected_member_type=selected_member_type,
        )

        st.plotly_chart(fig, use_container_width=True)

        # auto-save PNG of steel frame viewer
        outputs_dir = Path("outputs")
        outputs_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        frame_png_path = outputs_dir / f"steel_frame_viewer_{timestamp}.png"

        try:
            fig.write_image(str(frame_png_path), width=1600, height=900, scale=2)
            st.success(f"Steel frame viewer PNG auto-saved to: {frame_png_path}")
        except Exception as e:
            st.warning(
                "Steel frame viewer could not be saved as PNG. "
                "Install kaleido using: pip install kaleido"
            )

    with tab_diagrams:
        st.markdown(
            """
            <div class="hint-box">
            Beam shear force, bending moment, and deflection diagrams are shown automatically for every storey.
            </div>
            """,
            unsafe_allow_html=True,
        )
        for row in results:
            st.subheader(f"Storey {row['storey']} — {row['beam_section']} | {row['beam_grade']}")
            g1, g2, g3 = st.columns(3)
            with g1:
                st.plotly_chart(create_beam_sfd_plot(building, row), use_container_width=True)
            with g2:
                st.plotly_chart(create_beam_bmd_plot(building, row), use_container_width=True)
            with g3:
                st.plotly_chart(create_beam_deflection_plot(building, row), use_container_width=True)
            st.markdown("---")

    with tab_export:
        file_path = export_results_to_excel(results, summary, meta=meta)
        with open(file_path, "rb") as file_obj:
            st.download_button(
                label="Download Excel Results",
                data=file_obj,
                file_name=Path(file_path).name,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        st.success(f"Excel file prepared: {file_path}")


def _copy_storey_values(source_storey: int, target_storeys, all_sections):
    rows = st.session_state.get("live_storey_rows", [])
    if not rows:
        return

    src_idx = int(source_storey) - 1
    if src_idx < 0 or src_idx >= len(rows):
        return

    source_row = rows[src_idx]
    section_choices = _build_section_choices(all_sections)
    section_map = {choice.label: choice for choice in section_choices}

    for target_storey in target_storeys:
        tgt_idx = int(target_storey) - 1
        if tgt_idx < 0 or tgt_idx >= len(rows) or tgt_idx == src_idx:
            continue

        rows[tgt_idx]["height"] = source_row["height"]
        rows[tgt_idx]["dead_load"] = source_row["dead_load"]
        rows[tgt_idx]["live_load"] = source_row["live_load"]
        rows[tgt_idx]["beam_section"] = source_row["beam_section"]
        rows[tgt_idx]["beam_grade"] = source_row["beam_grade"]
        rows[tgt_idx]["column_section"] = source_row["column_section"]
        rows[tgt_idx]["column_grade"] = source_row["column_grade"]

        st.session_state[f"height_{tgt_idx}"] = float(source_row["height"])
        st.session_state[f"dead_{tgt_idx}"] = float(source_row["dead_load"])
        st.session_state[f"live_{tgt_idx}"] = float(source_row["live_load"])
        st.session_state[f"beam_grade_{tgt_idx}"] = source_row["beam_grade"]
        st.session_state[f"column_grade_{tgt_idx}"] = source_row["column_grade"]
        st.session_state[f"beam_section_{tgt_idx}"] = section_map[source_row["beam_section"]]
        st.session_state[f"column_section_{tgt_idx}"] = section_map[source_row["column_section"]]

    st.session_state["live_storey_rows"] = rows


def run_app():
    st.set_page_config(page_title="CE3204 Competition App", layout="wide")
    _inject_css()
    st.title("CE3204 Steel Frame Analysis & Optimization")

    if not database_ready():
        st.error("Database not found. Put the three Excel files into data/ and run: python -m src.database.import_from_excel")
        st.stop()

    all_sections = get_all_section_names()
    all_grades = get_all_material_grades()
    all_codes = get_all_design_standard_codes()

    if not all_sections or not all_grades or not all_codes:
        st.error("Database exists but required lookup tables are empty.")
        st.stop()

    component = st.radio("Select component", ["Component 1 - Analysis", "Component 2 - Optimization"], horizontal=True)

    with st.container(border=True):
        top_col1, top_col2, top_col3 = st.columns(3)
        with top_col1:
            num_storeys = st.number_input(
                "Number of storeys",
                min_value=1,
                max_value=20,
                value=st.session_state.get("num_storeys", 5),
                step=1,
                key="num_storeys",
            )
        with top_col2:
            span = st.number_input("Beam span (m)", min_value=1.0, max_value=20.0, value=4.0, step=0.5, key="span_input")
        with top_col3:
            design_standard = st.selectbox("Design standard", all_codes, key="design_standard_input")

    st.markdown(
        """
        <div class="section-card">
            <div class="section-title">Geometry and Loading</div>
            <div class="section-subtitle">Use the single dropdown only. Type inside it to search. It also matches compact forms such as UB254, UB 254, SHS40, or CHS101.6/10.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    with st.container(border=True):
        st.markdown("**Quick copy row values**")
        copy_col1, copy_col2, copy_col3 = st.columns([1, 2, 1])

        with copy_col1:
            source_storey = st.selectbox(
                "Copy from storey",
                options=list(range(1, int(num_storeys) + 1)),
                index=0,
                key="copy_source_storey",
            )

        with copy_col2:
            target_storeys = st.multiselect(
                "Paste into storeys",
                options=[i for i in range(1, int(num_storeys) + 1) if i != source_storey],
                default=[],
                key="copy_target_storeys",
            )

        with copy_col3:
            st.write("")
            st.write("")
            if st.button("Copy row values", use_container_width=True):
                _copy_storey_values(source_storey, target_storeys, all_sections)
                st.rerun()

    live_rows = _render_live_storey_inputs(int(num_storeys), all_sections, all_grades)
    st.session_state["live_storey_rows"] = live_rows

    constraints = None
    search_mode = None
    candidate_pool = None
    run_mode = "Analysis"
    governing_basis = "utilization"

    with st.container(border=True):
        if component.startswith("Component 1"):
            st.markdown('<div class="section-title">Analysis Settings</div>', unsafe_allow_html=True)
            governing_basis = st.selectbox("Governing criterion", ["utilization", "stress", "moment", "deflection"], index=0)
        else:
            st.markdown('<div class="section-title">Optimization Settings</div>', unsafe_allow_html=True)
            run_mode = st.selectbox("Optimization mode", ["Grouped Optimization", "Individual-Storey Optimization"], index=0)
            constraints = _render_constraints_panel(num_storeys=int(num_storeys), run_mode=run_mode)
            search_mode = constraints["search_mode"]
            candidate_pool = constraints["candidate_pool"]

    run_clicked = st.button("Run", type="primary", use_container_width=True)

    if not run_clicked:
        st.info("Set your inputs and click Run.")
        return

    try:
        storey_rows = _clean_storey_rows(
            pd.DataFrame(st.session_state["live_storey_rows"]),
            default_section=all_sections[0],
            default_grade=all_grades[0],
        )

        validation_errors = _validate_rows(storey_rows, all_sections, all_grades)
        if validation_errors:
            st.error("Please correct these input issues before running:")
            for item in validation_errors[:20]:
                st.write(f"- {item}")
            st.stop()

        building, design = build_building_from_rows(
            num_storeys=int(num_storeys),
            span=float(span),
            design_standard_code=design_standard,
            storey_rows=storey_rows,
        )

        if component.startswith("Component 1"):
            payload = run_analysis_service(building, design, governing_basis=governing_basis)
            _render_results(payload, component_label="Component 1")
        else:
            input_data = {
                "run_mode": run_mode,
                "constraints": constraints,
                "candidate_pool": candidate_pool,
                "search_mode": search_mode,
            }
            payload = run_optimization_service(building, design, input_data)
            if payload.get("summary") is None:
                st.error(payload.get("meta", {}).get("failure_reason", "No feasible optimization solution found."))
                if payload.get("meta"):
                    st.json(payload["meta"])
            else:
                _render_results(payload, component_label="Component 2")

    except Exception as exc:
        st.exception(exc)