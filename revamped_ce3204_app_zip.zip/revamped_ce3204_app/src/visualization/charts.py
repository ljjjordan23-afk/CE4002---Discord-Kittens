import plotly.graph_objects as go


# IPEC-friendly / color-blind-friendly palette
COLOR_LOW = "#009E73"         # green
COLOR_MODERATE = "#E69F00"    # orange
COLOR_HIGH = "#D55E00"        # vermillion
COLOR_SELECTED = "#0072B2"    # blue
COLOR_TEXT = "#1F2937"
COLOR_GRID = "#D9E2F1"
COLOR_FRAME_BG = "white"
COLOR_BEAM_FILL = "rgba(76,120,168,0.18)"
COLOR_MOMENT_FILL = "rgba(245,133,24,0.18)"
COLOR_DEFLECTED = "#CC79A7"
COLOR_LABEL_BG = "rgba(255,255,255,0.96)"
COLOR_LABEL_BORDER = "#AAB7C4"


def utilization_color(utilization: float) -> str:
    if utilization < 0.6:
        return COLOR_LOW
    if utilization < 0.8:
        return COLOR_MODERATE
    return COLOR_HIGH


def _governing_from_results(results):
    max_u = -1.0
    governing_member_type = "Beam"
    governing_storey = results[0]["storey"]

    for row in results:
        if float(row["beam_utilization"]) > max_u:
            max_u = float(row["beam_utilization"])
            governing_member_type = "Beam"
            governing_storey = int(row["storey"])
        if float(row["column_utilization"]) > max_u:
            max_u = float(row["column_utilization"])
            governing_member_type = "Column"
            governing_storey = int(row["storey"])

    return governing_member_type, governing_storey, max_u


def create_frame_figure(building, results, selected_storey=None, selected_member_type=None):
    results = sorted(results, key=lambda r: r["storey"])

    if selected_storey is None or selected_member_type is None:
        selected_member_type, selected_storey, _ = _governing_from_results(results)

    fig = go.Figure()

    x_left = 0.0
    x_right = float(building.span)
    total_height = sum(float(r["height_m"]) for r in results)
    current_y = 0.0

    # column labels kept near the left member
    left_label_x = x_left - 0.10

    # beam label x positions alternate across span to avoid overlap
    beam_label_x_pattern = [0.25, 0.75, 0.35, 0.65, 0.22, 0.78]

    # legend
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="lines", line=dict(color=COLOR_LOW, width=10), name="U < 0.6"))
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="lines", line=dict(color=COLOR_MODERATE, width=10), name="0.6 ≤ U < 0.8"))
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="lines", line=dict(color=COLOR_HIGH, width=10), name="U ≥ 0.8"))
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="lines", line=dict(color=COLOR_SELECTED, width=10), name="Governing member"))

    for idx, row in enumerate(results):
        storey = int(row["storey"])
        next_y = current_y + float(row["height_m"])

        beam_selected = selected_member_type == "Beam" and selected_storey == storey
        col_selected = selected_member_type == "Column" and selected_storey == storey

        beam_color = COLOR_SELECTED if beam_selected else utilization_color(float(row["beam_utilization"]))
        col_color = COLOR_SELECTED if col_selected else utilization_color(float(row["column_utilization"]))

        beam_width = 12 if beam_selected else 8
        col_width = 12 if col_selected else 8

        beam_hover = (
            f"<b>Beam - Storey {storey}</b><br>"
            f"Section: {row['beam_section']}<br>"
            f"Grade: {row['beam_grade']}<br>"
            f"Load: {row['design_load_kN_per_m']:.3f} kN/m<br>"
            f"Moment: {row['beam_Mmax_kNm']:.3f} kN·m<br>"
            f"Stress: {row['beam_stress_MPa']:.3f} MPa<br>"
            f"Utilization: {row['beam_utilization']:.3f}<br>"
            f"Deflection: {row['beam_deflection_mm']:.3f} mm"
        )

        col_hover = (
            f"<b>Column - Storey {storey}</b><br>"
            f"Section: {row['column_section']}<br>"
            f"Grade: {row['column_grade']}<br>"
            f"Axial force: {row['column_force_kN']:.3f} kN<br>"
            f"Stress: {row['column_stress_MPa']:.3f} MPa<br>"
            f"Utilization: {row['column_utilization']:.3f}"
        )

        # columns
        fig.add_trace(
            go.Scatter(
                x=[x_left, x_left],
                y=[current_y, next_y],
                mode="lines",
                line=dict(color=col_color, width=col_width),
                hovertemplate=col_hover + "<extra></extra>",
                showlegend=False,
            )
        )
        fig.add_trace(
            go.Scatter(
                x=[x_right, x_right],
                y=[current_y, next_y],
                mode="lines",
                line=dict(color=col_color, width=col_width),
                hovertemplate=col_hover + "<extra></extra>",
                showlegend=False,
            )
        )

        # beam
        fig.add_trace(
            go.Scatter(
                x=[x_left, x_right],
                y=[next_y, next_y],
                mode="lines",
                line=dict(color=beam_color, width=beam_width),
                hovertemplate=beam_hover + "<extra></extra>",
                showlegend=False,
            )
        )

        # beam label ON member with alternating x position
        x_fraction = beam_label_x_pattern[idx % len(beam_label_x_pattern)]
        beam_label_x = x_left + x_fraction * (x_right - x_left)

        fig.add_annotation(
            x=beam_label_x,
            y=next_y,
            text=(
                f"<b>B{storey}</b><br>"
                f"{row['beam_section']} | {row['beam_grade']}<br>"
                f"U = {row['beam_utilization']:.3f}"
            ),
            showarrow=False,
            xanchor="center",
            yanchor="middle",
            align="center",
            font=dict(size=17, color=COLOR_TEXT),
            bgcolor="rgba(255,255,255,0.98)",
            bordercolor=COLOR_LABEL_BORDER,
            borderwidth=1,
            borderpad=5,
        )

        # column label NEAR member
        fig.add_annotation(
            x=left_label_x,
            y=(current_y + next_y) / 2.0,
            text=(
                f"<b>C{storey}</b><br>"
                f"{row['column_section']}<br>"
                f"U = {row['column_utilization']:.3f}"
            ),
            showarrow=False,
            xanchor="right",
            yanchor="middle",
            align="right",
            font=dict(size=16, color=COLOR_TEXT),
            bgcolor="rgba(255,255,255,0.98)",
            bordercolor=COLOR_LABEL_BORDER,
            borderwidth=1,
            borderpad=5,
        )

        current_y = next_y

    fig.update_layout(
        title=dict(
            text="Steel Frame Viewer",
            x=0.03,
            xanchor="left",
            font=dict(size=28, color=COLOR_TEXT),
        ),
        paper_bgcolor=COLOR_FRAME_BG,
        plot_bgcolor=COLOR_FRAME_BG,
        font=dict(color=COLOR_TEXT, size=17),
        height=max(900, int(125 * building.num_storeys + 240)),
        margin=dict(l=135, r=80, t=95, b=85),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1.0,
            font=dict(size=14),
        ),
        hoverlabel=dict(font_size=15),
    )

    fig.update_xaxes(
        title=dict(text="Span (m)", font=dict(size=20, color=COLOR_TEXT)),
        range=[-0.35, float(building.span) + 0.35],
        tickfont=dict(size=14, color=COLOR_TEXT),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
        showline=True,
        linewidth=1,
        linecolor="#94A3B8",
    )

    fig.update_yaxes(
        title=dict(text="Height (m)", font=dict(size=20, color=COLOR_TEXT)),
        range=[0, total_height + 1.0],
        tickfont=dict(size=14, color=COLOR_TEXT),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
        showline=True,
        linewidth=1,
        linecolor="#94A3B8",
    )

    return fig

def create_beam_sfd_plot(building, result_row):
    beam = building.storeys[int(result_row["storey"]) - 1].beam
    data = beam.beam_diagram_data(float(result_row["design_load_kN_per_m"]), float(building.span))

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=data["x_m"],
            y=data["V_kN"],
            mode="lines",
            line=dict(color="#4C78A8", width=4),
            fill="tozeroy",
            fillcolor=COLOR_BEAM_FILL,
            name="Shear Force",
        )
    )

    fig.update_layout(
        title=dict(
            text=f"Beam Shear Force Diagram - Storey {result_row['storey']}",
            x=0.03,
            xanchor="left",
            font=dict(size=20, color=COLOR_TEXT),
        ),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color=COLOR_TEXT, size=14),
        height=380,
        margin=dict(l=60, r=30, t=70, b=55),
    )

    fig.update_xaxes(
        title=dict(text="Position along beam, x (m)", font=dict(size=16)),
        tickfont=dict(size=13),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
    )
    fig.update_yaxes(
        title=dict(text="Shear Force (kN)", font=dict(size=16)),
        tickfont=dict(size=13),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
    )
    return fig


def create_beam_bmd_plot(building, result_row):
    beam = building.storeys[int(result_row["storey"]) - 1].beam
    data = beam.beam_diagram_data(float(result_row["design_load_kN_per_m"]), float(building.span))

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=data["x_m"],
            y=data["M_kNm"],
            mode="lines",
            line=dict(color="#F58518", width=4),
            fill="tozeroy",
            fillcolor=COLOR_MOMENT_FILL,
            name="Bending Moment",
        )
    )

    fig.update_layout(
        title=dict(
            text=f"Beam Bending Moment Diagram - Storey {result_row['storey']}",
            x=0.03,
            xanchor="left",
            font=dict(size=20, color=COLOR_TEXT),
        ),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color=COLOR_TEXT, size=14),
        height=380,
        margin=dict(l=60, r=30, t=70, b=55),
    )

    fig.update_xaxes(
        title=dict(text="Position along beam, x (m)", font=dict(size=16)),
        tickfont=dict(size=13),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
    )
    fig.update_yaxes(
        title=dict(text="Bending Moment (kN·m)", font=dict(size=16)),
        tickfont=dict(size=13),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
    )
    return fig


def create_beam_deflection_plot(building, result_row):
    beam = building.storeys[int(result_row["storey"]) - 1].beam
    data = beam.beam_diagram_data(float(result_row["design_load_kN_per_m"]), float(building.span))

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=data["x_m"],
            y=data["y_mm"],
            mode="lines",
            line=dict(color=COLOR_DEFLECTED, width=4),
            name="Deflection",
        )
    )

    max_y = max(data["y_mm"]) if len(data["y_mm"]) else 0.0
    fig.add_annotation(
        x=float(building.span) / 2.0,
        y=max_y,
        text=f"δmax = {float(result_row['beam_deflection_mm']):.3f} mm",
        showarrow=True,
        arrowhead=2,
        ax=0,
        ay=-35,
        font=dict(size=13, color=COLOR_TEXT),
        bgcolor="rgba(255,255,255,0.94)",
        bordercolor=COLOR_LABEL_BORDER,
        borderwidth=1,
    )

    fig.update_layout(
        title=dict(
            text=f"Beam Deflection Curve - Storey {result_row['storey']}",
            x=0.03,
            xanchor="left",
            font=dict(size=20, color=COLOR_TEXT),
        ),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color=COLOR_TEXT, size=14),
        height=380,
        margin=dict(l=60, r=30, t=70, b=55),
    )

    fig.update_xaxes(
        title=dict(text="Position along beam, x (m)", font=dict(size=16)),
        tickfont=dict(size=13),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
    )
    fig.update_yaxes(
        title=dict(text="Deflection (mm)", font=dict(size=16)),
        tickfont=dict(size=13),
        showgrid=True,
        gridcolor=COLOR_GRID,
        zeroline=False,
    )
    return fig