# CE3204 Revamped Competition App

A cleaned-up Streamlit app for:
- **Component 1**: analysis of a simplified multi-storey steel frame
- **Component 2**: fast grouped optimization and individual-storey optimization

## Folder structure

- `app.py` - main Streamlit entry point
- `src/models` - building, member, section, material, design-standard classes
- `src/database` - SQLite queries and Excel-to-database importer
- `src/io` - conversion from UI table rows into model objects
- `src/analysis` - analysis engine and Excel export
- `src/optimization` - fast exact-by-group optimization engine
- `src/services` - orchestration layer
- `src/visualization` - frame plot and UI helpers
- `data` - place your Excel files and/or `sections.db` here
- `outputs` - generated Excel output files

## Expected data files
Place these in the `data/` folder:
- `member_section.xlsx`
- `material_cost.xlsx`
- `design_standard.xlsx`

Then run the importer once:

```bash
python -m src.database.import_from_excel
```

This will generate:
- `data/sections.db`

## Install and run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Notes

- Default optimization utilization range is **20% to 70%**.
- The app supports both **Grouped Optimization** and **Individual-Storey Optimization**.
- A **Fast** search mode uses candidate caps. A **Full** search mode uses the full filtered database.
- Group strings use formats such as:
  - `1 | 2-4 | 5`
  - `1-3 | 4-5`

## Competition workflow

1. Launch the app.
2. Select **Component 1** or **Component 2**.
3. Enter geometry and loading using the table editor.
4. For optimization, set constraints and search settings.
5. Click **Run**.
6. Review the summary, table, frame view, and export results.
7. streamlit run app.py
